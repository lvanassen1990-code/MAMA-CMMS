# MAMA Design System

> *"MAMA knows best."*

A design system for **MAMA — Maintenance Manager**, an AI-driven, Dutch-language CMMS (Computerized Maintenance Management System) SaaS platform. MAMA helps companies manage machines, equipment, work orders, spare parts, and preventive maintenance — with an intentionally calm, Apple-inspired interface.

---

## Source

| Source | Path / Link |
|---|---|
| Codebase (GitHub) | [`lvanassen1990-code/MAMA-CMMS`](https://github.com/lvanassen1990-code/MAMA-CMMS) (branch `main`) |
| Imported snapshot | `_source/` (read-only reference) |
| Backend schema | `_source/supabase/schema.sql` |

> All design tokens, components, copy, and naming in this kit were extracted directly from the codebase — not from screenshots. If the codebase moves, re-import and re-derive.

---

## Product

**MAMA** is a single product with three surfaces:

| Surface | Audience | Description |
|---|---|---|
| **Web (desktop)** | Manager / Admin | Full management, reporting, planning. Dense data tables. |
| **Tablet (iPad-first)** | Technician on the floor | Execute work orders, checklists, photos. Same web app, larger touch targets. |
| **Mobile (iOS + Android)** | Anyone | Free app, token login, report breakdowns. (Not yet built.) |

Today the codebase is the **desktop web app** only: a sidebar + topbar shell with rich data screens (Dashboard, Werkorders, Assets, Onderdelen, Onderhoudsplannen).

---

## Brand voice in one line

> Helder, kalm, professioneel Dutch with an `Apple-aesthetic`. The system never shouts; data does the talking.

---

## Index

| File | What's in it |
|---|---|
| `README.md` | This file — context, content + visual foundations, iconography, index |
| `SKILL.md` | Agent-Skills-compatible entry point |
| `colors_and_type.css` | All color + type tokens as CSS variables + semantic classes |
| `_source/` | Read-only snapshot of the imported codebase |
| `assets/` | Icons, fonts (substitution notes), brand mark assets |
| `preview/` | Small HTML preview cards rendered in the Design System tab |
| `ui_kits/web/` | Web-app UI kit — JSX components + click-through prototype |

---

## CONTENT FUNDAMENTALS

MAMA is **written in Dutch**. Every label, button, status, error, and notification you produce for this product must be in Dutch unless the user explicitly asks otherwise.

### Tone

- **Direct, professional, calm.** No exclamation marks. No marketing hype. No "Awesome!". Status messages are factual: `7 werkorders geladen`, not `Geweldig, 7 werkorders gevonden!`.
- **Helpful but not chatty.** The AI panel ("MAMA AI — inzicht van vandaag") gives one observation + one recommendation + 2–3 chip actions. It does not narrate.
- **Form over flourish.** Numbers, status badges, and bars carry the message. Prose is a fallback.

### Casing & punctuation

- **Sentence case** for headings, button labels, nav items, KPI labels: `Nieuwe werkorder`, `Actieve werkorders`, `Onderhoud kosten`. Never Title Case.
- **UPPERCASE small-caps** only for tiny eyebrow labels (section headers in the sidebar, KPI labels, table headers). Always with `letter-spacing: 0.5–0.8px` and `font-size: 10–11px`.
- **Sentence-final periods are dropped** on short UI labels and table cells. Used only in real sentences (AI message, notes, descriptions).
- **Currency:** `€ 3.840` — euro sign, space, Dutch thousands dot.
- **Time:** `4.2u` for hours (lowercase `u` = uur). Dates use `nl-NL` locale: `Zondag 10 mei 2026`, or short `10 mei`.
- **IDs/codes** are uppercase, hyphenated, monospaced: `WO-041`, `C-04`, `HP-07`, `TB-03`. Always rendered with `font-family: monospace; color: var(--text-3); font-size: 10–11px;`.

### Person & address

- **Address the user by first name + "je"** (informal Dutch). The greeting is `Goedemorgen, Leon 👋` — time-of-day aware (`Goedemorgen` / `Goedemiddag` / `Goedenavond`).
- **"We" is rare.** MAMA is a system, not a team. Use passive or imperative: `Werkorder aangemaakt`, `Selecteer een asset`.
- **AI speaks as MAMA**, not as a separate "assistant": `MAMA AI — inzicht van vandaag`. It recommends ("Aanbevolen actie: …"), it does not opine.

### Vocabulary

Use the in-product Dutch vocabulary literally — these are the canonical terms:

| Concept | Dutch term |
|---|---|
| Asset / machine | **Asset** (also `Machine`) |
| Work order | **Werkorder** (abbrev. `WO`) |
| Maintenance plan | **Onderhoudsplan** |
| Spare part | **Onderdeel** |
| Breakdown / failure | **Storing** |
| Location | **Locatie** (`Hal A`, `Hal B`, …) |
| Inspection | **Inspectie** |
| Preventive | **Preventief** |
| Corrective | **Correctief** |
| In progress | **In uitvoering** |
| Waiting on parts | **Wacht op onderdelen** |
| Completed | **Voltooid** / **Klaar** |
| Cancelled | **Geannuleerd** |
| Critical | **Kritiek** |
| High | **Hoog** |
| Normal | **Normaal** |
| Low | **Laag** |
| Operational | **Operationeel** |
| Watch / warning | **Let op** |
| Out of service | **Buiten gebruik** |
| Written off | **Afgeschreven** |

### Emoji

- **One emoji exists in the product:** `👋` in the time-of-day greeting (`Goedemorgen, Leon 👋`).
- **Do not introduce other emoji.** Status, severity, and category are communicated via **colored dot + badge**, never with 🔴🟢🟡.

### Sample copy

- **Topbar greeting:** `Goedemorgen, Leon 👋` · `Zondag 10 mei 2026 · 3 actieve storingen`
- **AI panel:** *"Compressor #C-04 toont afwijkende trillingpatronen. Aanbevolen actie: inspectie inplannen vóór donderdag. Verder zijn 2 onderhoudsorders deze week verlopen zonder afsluiting."*
- **Empty state (parts):** *"Geen onderdelen gekoppeld aan deze werkorder"*
- **KPI label + sub:** `WERKORDERS` · `34` · `7 openstaand · 3 verlopen` · `↓ 2 verlopen deadline`
- **Button labels:** `Nieuwe werkorder`, `Exporteer`, `Status wijzigen`, `Markeer voltooid`, `Annuleren`, `Opslaan`.

---

## VISUAL FOUNDATIONS

MAMA's visual system is unambiguously **Apple-inspired enterprise software**: white surfaces, hairline borders, generous breathing room, a near-black accent, and a clear semantic color palette. It looks like a tool, not a billboard.

### Color

- **Foundation:** off-white page (`#f5f5f7`), pure white surfaces (`#ffffff`), near-black ink (`#1d1d1f`), three text grays (`#1d1d1f → #6e6e73 → #aeaeb2`).
- **Accent (primary action):** `#1a1a1a` near-black. There is no brand-blue accent — the *only* thing that's brand-colored is the logo mark.
- **Semantic palette** is fixed and used everywhere identically:
  - Green `#1D9E75` — operational / completed / on-track
  - Amber `#EF9F27` — warning / in progress
  - Red `#E24B4A` — critical / overdue / breakdown
  - Blue `#378ADD` — informational / "Open" status / avatar fill
  - Purple `#8B5CF6` — waiting on parts
- Each semantic hue has a **trio**: solid (`--green`), tinted background (`--green-bg`), darkened text (`--green-text`). Always use the trio together when building badges/chips so contrast stays predictable.

### Typography

- **Single typeface:** Inter, weights 400 / 500 / 600. Loaded from Google Fonts. Fallback stack `-apple-system, BlinkMacSystemFont, sans-serif`.
- **Monospaced**: the system stack `monospace` is used for IDs (WO-041, part numbers) at 10–11px.
- **Sizes are small.** The base body size is `14px`. KPI values are the largest text on a page at `24–26px`. Headings and titles top out at `15px`. There is no display type.
- **Weights:** body 400, labels & buttons 500, brand mark & numbers 600.
- **Line height:** 1.5 globally; 1 for big numbers.
- **No italics.** No underlines except focus rings.

### Spacing

- Page outer padding `20px 24px`. Card padding `14–16px`. Section gaps `12–16px`.
- Sidebar `220px`. Topbar `12px` vertical padding.
- Grid gaps are tight: `8–12px` for KPI rows, `16px` for content cards.

### Borders, hairlines, radii

- **0.5px hairline borders** everywhere (`border: 0.5px solid rgba(0,0,0,0.08)`). This is the single most distinctive visual fingerprint of the system. Never use 1px or thicker borders on cards/tables.
- A second, slightly stronger hairline (`rgba(0,0,0,0.14)`) is used on inputs and buttons.
- **Radii:** `10px` (cards), `7px` (buttons, inputs, nav items), `20px` / `999px` (chips, badges), `50%` (avatars, dots), `8px` (logo mark), `14px` (modal).

### Shadows / elevation

- **Cards have no shadow.** They sit on the page with hairline borders only.
- **Modals** use a soft drop shadow `0 24px 64px rgba(0,0,0,0.12)` and a 14px radius.
- **Drawers** use a side shadow `-8px 0 32px rgba(0,0,0,0.10)`.
- No inner shadows anywhere.

### Backgrounds

- No gradients, no textures, no full-bleed imagery in the product UI.
- The only "imagery" is the **asset photo** in the work-order drawer (real photos of machines, fit-cover'd). When absent, fall back to a Tabler icon centered on `--bg`.
- **No hero illustrations.** No abstract shapes. No isometric drawings.

### Animation

- **Subtle and fast.** Standard transition `0.12s` for hover, `0.18s` for modal scale, `0.22–0.26s` for drawer slide with `cubic-bezier(0.4, 0, 0.2, 1)`.
- **Properties only:** `background`, `color`, `opacity`, `transform`, `border-color`. Never animate `width`, `height`, or `top/left`.
- **No bouncy or spring easings.** No looping animation. No "wow" moments.

### States

- **Hover:** background tint to `var(--bg)` (`#f5f5f7`) for buttons / nav items / table rows. Text color promotes one level (e.g. `--text-2` → `--text`).
- **Active / pressed:** no transform-scale shrink. Just a slightly darker background (`#333` on the black primary button).
- **Active nav:** same `var(--bg)` background as hover, but with `font-weight: 500` and `color: var(--text)`.
- **Selected chip:** swaps from grey (`--bg` + muted text) to its colored trio (`*-bg`, border in the solid hue, `*-text` for label). Inactive chips drop to `opacity: 0.45`.
- **Focus:** input gets `border-color: var(--blue)` and `background: var(--surface)` (swap from `--bg`). No outline rings.
- **Disabled:** dropped opacity, no other treatment.

### Layering & transparency

- **Backdrop blur** is used **only** on modal overlays (`rgba(0,0,0,0.3) + backdrop-filter: blur(4px)`).
- Drawer overlay is a plain `rgba(0,0,0,0.18)`, no blur.
- The product itself never uses translucency on its surfaces. White is white.

### Cards

Anatomy: hairline border + 10px radius + white background + 14–16px padding. Optional header with a 13px title (icon-prefixed, weight 500), and a right-side `card-action` link in 11px tertiary text.

### Tables

- Header row uses `--bg` fill, 10px uppercase tertiary-grey labels with letter-spacing.
- Body rows are 12px text, hairline-divided, with `background 0.1s` hover.
- A clickable row has cursor `default` and reveals an action button on the right (status change, etc.) — rows are not navigationally `pointer` cursors.
- **Severity tint on full rows** is rare and reserved for stock pages (`stock-low` = warm cream, `stock-empty` = soft red wash).

### Badges & dots

- Pill-shape badge: `font-size: 10px; padding: 2px 8px; border-radius: 10px; font-weight: 500;` always with a `bg`-tinted background and `text`-darkened label from the matching trio.
- 6px or 8px colored dot pairs with badges to give pre-attentive cues. Active-state dots are full opacity; inactive (in chip groups) drop to `0.4`.

### Charts

- **Donut:** SVG, `stroke-width: 10`, `stroke-linecap: round`, segments in semantic hues over a `#f0f0f0` track. Total in the center as 13–14px medium.
- **Horizontal bars:** `height: 6px`, radius `3px`, track `--bg`, fill in semantic green/amber/red.
- **No line charts, no axes, no grid lines** in current screens.

### Logo

- **Mark**: rounded-square tile with a vibrant blue gradient (`#0A84FF → #003E9E`, top-left → bottom-right) and a stylised white `M` rendered as a 34-stroke open path (`V-up / V-down / V-up`). At sizes ≥ 56px the tile uses radius `56/260 × size`; at 32px it falls back to `8px` radius. Source: `assets/logo-mark.svg`. Original full-lockup reference: `assets/logo-original.svg`.
- **Wordmark**: `MAMA` in Inter 600 (14px in sidebar, 20–30px display). `Maintenance Manager` tagline below in 10–11px uppercase, letter-spacing 0.6px, color `--text-3`. Strapline `"MAMA knows best."` is reserved for hero contexts only.
- **Tile is now the brand color anchor.** The near-black `--accent` token still drives primary buttons and the AI tile; the blue mark is the only place the gradient appears in the UI.

---

## ICONOGRAPHY

- **Source:** [Tabler Icons](https://tabler-icons.io) v2.44.0 via CDN — `cdnjs.cloudflare.com/ajax/libs/tabler-icons/2.44.0/iconfont/tabler-icons.min.css`. **Use this; do not substitute.**
- **Form:** Tabler is a 24px stroke set. In MAMA it's rendered at `13–16px` and inherits `currentColor`. The native Tabler stroke weight is what gives the UI its consistent line feel.
- **No SVG sprites of our own.** No PNG icons. Never hand-roll an SVG icon when a Tabler one exists.
- **Decorative use:** never. Every icon either prefixes a label (nav, button, KPI), marks a category (asset category map: `Compressor → ti-wind`, `Hydrauliek → ti-droplet`, `Ventilatie → ti-air-conditioning`, `Transport → ti-arrows-right-left`, `Elektrisch → ti-bolt`, `Koeling → ti-snowflake`), or stands alone as an empty-state glyph at 24–48px in `--text-3`.

### Canonical icon map

| Concept | Tabler class |
|---|---|
| Dashboard | `ti-layout-dashboard` |
| Assets / machine | `ti-building-factory-2` |
| Werkorders | `ti-clipboard-list` |
| Planning | `ti-calendar-event` |
| Storingen | `ti-alert-triangle` |
| Onderdelen | `ti-box` |
| Onderhoudsplannen | `ti-clipboard-text` |
| Quality Control | `ti-shield-check` |
| Rapportages | `ti-chart-bar` |
| Power BI | `ti-brand-windows` |
| API & Webhooks | `ti-plug` |
| Settings | `ti-settings` |
| Search | `ti-search` |
| Add / new | `ti-plus` |
| Close | `ti-x` |
| Refresh / status change | `ti-refresh` |
| Start | `ti-player-play` |
| Done / check | `ti-check` / `ti-circle-check` |
| Warning / overdue | `ti-alert-circle` |
| Download / export | `ti-download` |
| Clock / MTTR | `ti-clock` |
| Uptime | `ti-activity` |
| Donut chart | `ti-chart-donut` |

### Emoji

`👋` in the greeting only. Nowhere else.

### Unicode glyphs

- `→` is used inside `card-action` text-links ("Alles bekijken →").
- `·` is a separator in subtitles and labels (`Hal A · Lijn 1`).
- `↑` / `↓` are used in KPI trend rows, colored with `--green-text` / `--red-text`.
- `€` for currency. Always followed by a non-breaking space.
