# MAMA — Web UI kit

The MAMA web app is the **manager / admin desktop surface**: sidebar + topbar shell, rich data screens, drawers and modals for detail/edit flows. Built as a high-fidelity click-through, not production code.

## Files

| File | Purpose |
|---|---|
| `index.html` | Click-through prototype. Boots a five-screen demo: Dashboard, Werkorders, Assets, Onderdelen, Onderhoudsplannen. |
| `app.jsx` | Routes between screens; owns demo state (work orders, drawer, modal). |
| `components.jsx` | Shared atoms — Sidebar, Topbar, Card, KpiCard, Badge, Chip, Button, Avatar, IconTile. |
| `screens.jsx` | Page-level compositions — DashboardScreen, WerkordersScreen, AssetsScreen, OnderdelenScreen, OnderhoudsplannenScreen. |
| `drawers.jsx` | WorkOrderDrawer + NewWorkOrderModal. |

## Interactions covered

- Switch screens via sidebar
- Open a work-order row → side drawer slides in from the right
- Click **Nieuwe werkorder** → modal opens, fields fill, submit creates a new WO at the top of the list
- Hover/active states on nav, table rows, chips
- Filter chips toggle on Werkorders / Onderdelen screens

## Visual sources

Every visual decision is sourced from `_source/index.html` (dashboard), `_source/dashboard.html` (dashboard v2), `_source/pages/werkorders.html`, `_source/pages/assets.html`, `_source/pages/onderdelen.html`, `_source/pages/onderhoudsplannen.html`.

> ⚠ The mobile token-app and the iPad technician view are **not yet built in the source codebase** — there is no UI kit for them here. Ask the user when those exist.
