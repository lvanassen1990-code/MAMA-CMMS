/* MAMA Web UI kit — app shell. Routes screens, owns drawer + modal state. */

const { useState: useStateA } = React;

const TITLES = {
  dashboard: 'Dashboard',
  werkorders: 'Werkorders',
  assets: 'Assets',
  storingen: 'Storingen',
  planning: 'Planning',
  onderdelen: 'Onderdelen',
  onderhoudsplannen: 'Onderhoudsplannen',
  qc: 'Quality Control',
  rapportages: 'Rapportages',
  powerbi: 'Power BI',
  api: 'API & Webhooks',
};

function App() {
  const [route, setRoute]     = useStateA('dashboard');
  const [workOrders, setWO]   = useStateA(window.MOCK_WO);
  const [drawerWO, setDrawerWO] = useStateA(null);
  const [drawerOpen, setDrawerOpen] = useStateA(false);
  const [modalOpen, setModalOpen]   = useStateA(false);

  const openWO  = (w) => { setDrawerWO(w); setDrawerOpen(true); };
  const closeDrawer = () => setDrawerOpen(false);
  const complete = (id) => {
    setWO(arr => arr.map(w => w.id === id ? { ...w, status: 'done', due: 'Afgerond', dueCls: 'text-3' } : w));
    setDrawerOpen(false);
  };
  const createWO = (w) => {
    setWO(arr => [w, ...arr]);
    setModalOpen(false);
    setRoute('werkorders');
  };

  const screen = (() => {
    switch (route) {
      case 'dashboard':         return <DashboardScreen openWO={openWO} />;
      case 'werkorders':        return <WerkordersScreen workOrders={workOrders} openWO={openWO} />;
      case 'assets':            return <AssetsScreen />;
      case 'onderdelen':        return <OnderdelenScreen />;
      case 'onderhoudsplannen': return <OnderhoudsplannenScreen />;
      default:
        return (
          <div className="page">
            <Card>
              <div style={{ padding: 24, textAlign: 'center', color: 'var(--text-3)', fontSize: 13 }}>
                <i className="ti ti-tool" style={{ fontSize: 28, display:'block', marginBottom: 8 }}></i>
                <div style={{ color: 'var(--text-2)', fontWeight: 500, marginBottom: 4 }}>{TITLES[route]} — in ontwikkeling</div>
                <div>Deze pagina staat in de roadmap. Selecteer Dashboard, Werkorders, Assets, Onderdelen of Onderhoudsplannen om de UI kit te bekijken.</div>
              </div>
            </Card>
          </div>
        );
    }
  })();

  return (
    <div className="app">
      <Sidebar active={route} onNavigate={setRoute} />
      <div className="main">
        <Topbar
          title={TITLES[route] || 'MAMA'}
          action={<Button variant="primary" icon="ti-plus" onClick={()=>setModalOpen(true)}>Nieuwe werkorder</Button>}
        />
        {screen}
      </div>
      <WorkOrderDrawer wo={drawerWO} open={drawerOpen} onClose={closeDrawer} onComplete={complete} />
      <NewWorkOrderModal open={modalOpen} onClose={()=>setModalOpen(false)} onCreate={createWO} />
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
