/* MAMA Web UI kit — shared atomic components.
   Load AFTER React + Babel and BEFORE app.jsx / screens.jsx. */

const { useState } = React;

// ── Sidebar ────────────────────────────────────────────────────────
const SIDEBAR_NAV = [
  { section: 'Navigatie', items: [
    { id: 'dashboard',   label: 'Dashboard',           icon: 'ti-layout-dashboard' },
    { id: 'werkorders',  label: 'Werkorders',          icon: 'ti-clipboard-list', count: 7 },
    { id: 'assets',      label: 'Assets',              icon: 'ti-building-factory-2' },
    { id: 'storingen',   label: 'Storingen',           icon: 'ti-alert-triangle', count: 3 },
    { id: 'planning',    label: 'Planning',            icon: 'ti-calendar-event' },
  ]},
  { section: 'Beheer', items: [
    { id: 'onderdelen',         label: 'Onderdelen',         icon: 'ti-box' },
    { id: 'onderhoudsplannen',  label: 'Onderhoudsplannen',  icon: 'ti-clipboard-text' },
    { id: 'qc',                 label: 'Quality Control',    icon: 'ti-shield-check' },
  ]},
  { section: 'Inzichten', items: [
    { id: 'rapportages', label: 'Rapportages',         icon: 'ti-chart-bar' },
    { id: 'powerbi',     label: 'Power BI',            icon: 'ti-brand-windows' },
    { id: 'api',         label: 'API & Webhooks',      icon: 'ti-plug' },
  ]},
];

function Sidebar({ active, onNavigate }) {
  return (
    <aside className="sb">
      <div className="sb-logo">
        <img className="sb-tile-img" src="../../assets/logo-mark.svg" width="32" height="32" alt="MAMA" />
        <div className="sb-brand">
          <span className="sb-brand-name">MAMA</span>
          <span className="sb-brand-tag">Maintenance Manager</span>
        </div>
      </div>
      {SIDEBAR_NAV.map(group => (
        <React.Fragment key={group.section}>
          <div className="sb-section">{group.section}</div>
          {group.items.map(it => (
            <div key={it.id}
                 className={'sb-item' + (active === it.id ? ' active' : '')}
                 onClick={() => onNavigate(it.id)}>
              <i className={'ti ' + it.icon}></i>
              <span>{it.label}</span>
              {it.count != null && <span className="ncount">{it.count}</span>}
            </div>
          ))}
        </React.Fragment>
      ))}
    </aside>
  );
}

// ── Topbar ─────────────────────────────────────────────────────────
function Topbar({ title, subtitle, action }) {
  const greeting = (() => {
    const h = new Date().getHours();
    if (h < 12) return 'Goedemorgen';
    if (h < 18) return 'Goedemiddag';
    return 'Goedenavond';
  })();
  const today = new Date().toLocaleDateString('nl-NL', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);
  return (
    <header className="tb">
      <div>
        <div className="tb-title">{title}</div>
        <div className="tb-sub">{subtitle || `${greeting}, Leon 👋 · ${cap(today)} · 3 actieve storingen`}</div>
      </div>
      <div className="spacer"></div>
      <div className="tb-search"><i className="ti ti-search"></i><input placeholder="Zoek werkorders, assets, onderdelen…" /></div>
      {action}
    </header>
  );
}

// ── Button ─────────────────────────────────────────────────────────
function Button({ variant, size, icon, children, onClick, type }) {
  const cls = 'btn' + (variant ? ' ' + variant : '') + (size === 'sm' ? ' sm' : '');
  return (
    <button type={type || 'button'} className={cls} onClick={onClick}>
      {icon && <i className={'ti ' + icon}></i>}
      {children}
    </button>
  );
}

// ── Card ───────────────────────────────────────────────────────────
function Card({ title, icon, action, flat, children, style }) {
  if (!title && !action) {
    return <div className={'card' + (flat ? ' flat' : '')} style={style}>{children}</div>;
  }
  return (
    <div className={'card' + (flat ? ' flat' : '')} style={Object.assign(flat ? { padding: 0 } : {}, style || {})}>
      <div className="card-head">
        <div className="card-title">{icon && <i className={'ti ' + icon}></i>}{title}</div>
        {action && <span className="card-action">{action} →</span>}
      </div>
      {children}
    </div>
  );
}

// ── KPI ────────────────────────────────────────────────────────────
function Kpi({ icon, label, value, sub, trend, trendDir }) {
  return (
    <div className="kpi">
      <div className="kpi-l">{icon && <i className={'ti ' + icon}></i>}{label}</div>
      <div className="kpi-v">{value}</div>
      {sub && <div className="kpi-s">{sub}</div>}
      {trend && <div className={'kpi-t ' + (trendDir || 'up')}>{trendDir === 'down' ? '↓' : '↑'} {trend}</div>}
    </div>
  );
}

// ── Badge / Priority ───────────────────────────────────────────────
const STATUS = {
  open:   { label: 'Open',                 cls: 'bg-blue',   dot: 'var(--blue)' },
  prog:   { label: 'In uitvoering',        cls: 'bg-amber',  dot: 'var(--amber)' },
  wacht:  { label: 'Wacht op onderdelen',  cls: 'bg-purple', dot: 'var(--purple)' },
  done:   { label: 'Voltooid',             cls: 'bg-green',  dot: 'var(--green)' },
  cancel: { label: 'Geannuleerd',          cls: 'bg-neutral',dot: 'var(--text-3)' },
};
function StatusBadge({ status }) {
  const s = STATUS[status] || STATUS.open;
  return <span className={'badge ' + s.cls}><span className="dot" style={{ background: s.dot }}></span>{s.label}</span>;
}
const ASSET_STATE = {
  op:       { label: 'Operationeel',   cls: 'bg-green' },
  watch:    { label: 'Let op',         cls: 'bg-amber' },
  storing:  { label: 'Storing',        cls: 'bg-red' },
  out:      { label: 'Buiten gebruik', cls: 'bg-neutral' },
};
function AssetStateBadge({ state }) {
  const s = ASSET_STATE[state] || ASSET_STATE.op;
  return <span className={'badge ' + s.cls}>{s.label}</span>;
}
const PRIO = {
  crit: { label: 'Kritiek', cls: 'bg-red' },
  high: { label: 'Hoog',    cls: 'bg-amber' },
  norm: { label: 'Normaal', cls: 'bg-neutral' },
  low:  { label: 'Laag',    cls: 'bg-neutral' },
};
function PriorityChip({ p }) {
  const x = PRIO[p] || PRIO.norm;
  return <span className={'prio ' + x.cls} style={p === 'low' ? { color: 'var(--text-3)' } : null}>{x.label}</span>;
}

// ── Chip ───────────────────────────────────────────────────────────
function FilterChip({ active, color, dot, children, onClick }) {
  return (
    <span className={'chip' + (active ? ' active ' + color : '')} onClick={onClick}>
      {dot && <span className="d" style={{ background: dot }}></span>}{children}
    </span>
  );
}

// ── Field ──────────────────────────────────────────────────────────
function Field({ label, full, children }) {
  return <div className={'field' + (full ? ' full' : '')}>{label && <label className="field-l">{label}</label>}{children}</div>;
}

// ── AI panel ───────────────────────────────────────────────────────
function AiPanel({ message, actions }) {
  return (
    <div className="ai">
      <div className="ai-tile">AI</div>
      <div style={{ flex: 1 }}>
        <div className="ai-t">MAMA AI — inzicht van vandaag</div>
        <div className="ai-m">{message}</div>
        <div className="ai-chips">{actions.map(a => <div key={a} className="ai-chip">{a}</div>)}</div>
      </div>
    </div>
  );
}

// ── Avatar ─────────────────────────────────────────────────────────
function Avatar({ name }) {
  const initials = name.split(/[ .]/).filter(Boolean).map(s => s[0]).slice(0, 2).join('').toUpperCase();
  return <span className="avatar">{initials}</span>;
}

// ── IconTile (decorative icon tile prefix on rows) ────────────────
function IconTile({ icon }) {
  return <span className="icontile"><i className={'ti ' + icon}></i></span>;
}

// ── Donut chart (SVG) ──────────────────────────────────────────────
function Donut({ size = 110, segments }) {
  const r = size / 2 - 6;
  const C = 2 * Math.PI * r;
  const total = segments.reduce((a, s) => a + s.value, 0);
  let offset = 0;
  return (
    <div className="donut-wrap">
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="#f0f0f0" strokeWidth="10" />
        {segments.map((s, i) => {
          const len = (s.value / total) * C;
          const el = (
            <circle key={i} cx={size/2} cy={size/2} r={r} fill="none"
                    stroke={s.color} strokeWidth="10" strokeLinecap="round"
                    strokeDasharray={`${len} ${C - len}`}
                    strokeDashoffset={-offset}
                    transform={`rotate(-90 ${size/2} ${size/2})`} />
          );
          offset += len;
          return el;
        })}
        <text x="50%" y="50%" textAnchor="middle" dy="0.35em" fontSize="13" fontWeight="500" fill="var(--text)">{total}</text>
      </svg>
      <div className="donut-legend">
        {segments.map(s => (
          <div className="row" key={s.label}>
            <span className="dot" style={{ background: s.color }}></span>
            <span>{s.label}</span>
            <span className="n">{s.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── BarRow ─────────────────────────────────────────────────────────
function BarRow({ label, value, max, color }) {
  const pct = Math.min(100, (value / max) * 100);
  return (
    <div className="bar-row">
      <span className="lbl">{label}</span>
      <div className="track"><div className="fill" style={{ width: pct + '%', background: color }}></div></div>
      <span className="v">{value}</span>
    </div>
  );
}

Object.assign(window, {
  Sidebar, Topbar, Button, Card, Kpi, StatusBadge, AssetStateBadge, PriorityChip,
  FilterChip, Field, AiPanel, Avatar, IconTile, Donut, BarRow,
  STATUS, ASSET_STATE, PRIO,
});
