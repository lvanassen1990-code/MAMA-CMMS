/* MAMA Web UI kit — page-level compositions and drawers. */

const { useState: useStateS } = React;

// ── Mock data ──────────────────────────────────────────────────────
window.MOCK_ASSETS = [
  { id: 'C-04',  name: 'Compressor #C-04',          cat: 'Compressor',  catIcon: 'ti-wind',                loc: 'Hal A · Lijn 1', state: 'watch' },
  { id: 'HP-07', name: 'Hydrauliekpomp HP-07',      cat: 'Hydrauliek',  catIcon: 'ti-droplet',             loc: 'Hal C · Pers 2', state: 'storing' },
  { id: 'TB-03', name: 'Transportband TB-03',       cat: 'Transport',   catIcon: 'ti-arrows-right-left',   loc: 'Hal B · Lijn 3', state: 'op' },
  { id: 'SK-12', name: 'Schakelkast SK-12',         cat: 'Elektrisch',  catIcon: 'ti-bolt',                loc: 'Hal A · Centraal', state: 'op' },
  { id: 'VL-02', name: 'Ventilator VL-02',          cat: 'Ventilatie',  catIcon: 'ti-air-conditioning',    loc: 'Hal B · Dak',   state: 'op' },
  { id: 'KK-05', name: 'Koelinstallatie KK-05',     cat: 'Koeling',     catIcon: 'ti-snowflake',           loc: 'Hal D',         state: 'out' },
];

window.MOCK_WO = [
  { id: 'WO-041', desc: 'Smering lagerblok lijn 3',         asset: 'Transportband TB-03',     loc: 'Hal B', prio: 'norm', status: 'prog',  who: 'J. de Vries', due: 'over 2d',     dueCls: 'amber', kind: 'preventief' },
  { id: 'WO-042', desc: 'Inspectie hydrauliekpomp',         asset: 'Hydrauliekpomp HP-07',    loc: 'Hal C', prio: 'crit', status: 'open',  who: 'M. Bakker',  due: '3d verlopen', dueCls: 'red',   kind: 'correctief' },
  { id: 'WO-040', desc: 'Vervang filter compressor',        asset: 'Compressor #C-04',        loc: 'Hal A', prio: 'high', status: 'wacht', who: 'J. de Vries', due: 'over 5d',     dueCls: 'text-2',kind: 'correctief' },
  { id: 'WO-039', desc: 'Elektrische keuring schakelkast',  asset: 'Schakelkast SK-12',       loc: 'Hal A', prio: 'low',  status: 'done',  who: 'R. Smit',    due: 'Afgerond',    dueCls: 'text-3',kind: 'preventief' },
  { id: 'WO-038', desc: 'Reiniging ventilatieroosters',     asset: 'Ventilator VL-02',        loc: 'Hal B', prio: 'norm', status: 'done',  who: 'R. Smit',    due: 'Afgerond',    dueCls: 'text-3',kind: 'preventief' },
  { id: 'WO-037', desc: 'Storingsanalyse koelinstallatie',  asset: 'Koelinstallatie KK-05',   loc: 'Hal D', prio: 'high', status: 'cancel',who: 'M. Bakker',  due: 'Geannuleerd', dueCls: 'text-3',kind: 'correctief' },
];

window.MOCK_PARTS = [
  { id: 'BL-220-15', name: 'Lager 220-15',           cat: 'Mechanisch', stock: 12, min: 4,  unit: '€ 14,20', state: 'ok'   },
  { id: 'FL-AIR-04', name: 'Luchtfilter type 04',     cat: 'Filtratie',  stock: 3,  min: 5,  unit: '€ 8,50',  state: 'low'  },
  { id: 'OIL-ISO46', name: 'Hydrauliekolie ISO 46',   cat: 'Smering',    stock: 0,  min: 2,  unit: '€ 32,00', state: 'empty'},
  { id: 'BLT-M10-40',name: 'Bout M10×40 RVS',         cat: 'Bevestiging',stock: 220,min: 50, unit: '€ 0,12',  unit2:'/stuk', state: 'ok' },
  { id: 'CBL-VVB-15',name: 'Kabel VVB 3×1,5',         cat: 'Elektrisch', stock: 65, min: 25, unit: '€ 1,80',  unit2:'/m',    state: 'ok' },
];

window.MOCK_PLANS = [
  { id: 'OP-01', name: 'Smering lagers wekelijks',      asset: 'Transportband TB-03',   interval: 'Elke 7 dagen',  next: 'Over 3 dagen',  state: 'active' },
  { id: 'OP-02', name: 'Filtervervanging compressor',   asset: 'Compressor #C-04',      interval: 'Elke 90 dagen', next: 'Over 22 dagen', state: 'active' },
  { id: 'OP-03', name: 'Elektrische keuring jaarlijks', asset: 'Schakelkast SK-12',     interval: 'Elk jaar',      next: 'Over 4 maanden',state: 'active' },
  { id: 'OP-04', name: 'Hydrauliekolie verversen',      asset: 'Hydrauliekpomp HP-07',  interval: 'Elke 180 dagen',next: 'Verlopen — 5d', state: 'overdue' },
];

// ── Dashboard ─────────────────────────────────────────────────────
function DashboardScreen({ openWO }) {
  return (
    <div className="page">
      <div className="grid-4">
        <Kpi icon="ti-building-factory-2" label="Assets"      value="148"     sub="12 locaties"           trend="4 toegevoegd deze maand" trendDir="up"/>
        <Kpi icon="ti-clipboard-list"     label="Werkorders"  value="34"      sub="7 openstaand · 3 verlopen" trend="2 verlopen deadline" trendDir="down"/>
        <Kpi icon="ti-clock"              label="Gem. MTTR"   value="4.2u"    sub="Mean Time To Repair"   trend="12% beter dan vorige maand" trendDir="up"/>
        <Kpi icon="ti-activity"           label="Uptime"      value={<span style={{color:'var(--green)'}}>96.4%</span>} sub="Afgelopen 30 dagen" trend="Doel: 95% ✓" trendDir="up"/>
      </div>

      <AiPanel
        message='Compressor #C-04 toont afwijkende trillingpatronen. Aanbevolen actie: inspectie inplannen vóór donderdag. Verder zijn 2 onderhoudsorders deze week verlopen zonder afsluiting.'
        actions={['Werkorder aanmaken', 'Bekijk C-04 details', 'Verlopen orders tonen']}
      />

      <div className="grid-3">
        <Card title="Werkorder status" icon="ti-chart-donut" action="Alles bekijken" style={{minHeight:200}}>
          <Donut segments={[
            { label: 'Open',                value: 7, color: 'var(--blue)' },
            { label: 'In uitvoering',       value: 4, color: 'var(--amber)' },
            { label: 'Wacht op onderdelen', value: 2, color: 'var(--purple)' },
            { label: 'Voltooid (30d)',      value: 21,color: 'var(--green)' },
          ]} />
        </Card>
        <Card title="Onderhoudskosten" icon="ti-currency-euro" action="Rapportage">
          <BarRow label="Hal A" value={1240} max={1800} color="var(--blue)" />
          <BarRow label="Hal B" value={1620} max={1800} color="var(--blue)" />
          <BarRow label="Hal C" value={ 880} max={1800} color="var(--blue)" />
          <BarRow label="Hal D" value={ 410} max={1800} color="var(--blue)" />
          <div style={{ display:'flex', justifyContent:'space-between', marginTop:10, paddingTop:10, borderTop:'0.5px solid var(--border)', fontSize:11 }}>
            <span style={{color:'var(--text-2)'}}>Totaal deze maand</span>
            <span style={{fontWeight:500}}>€ 4.150</span>
          </div>
        </Card>
        <Card title="Recente storingen" icon="ti-alert-triangle" action="Alle storingen">
          {[
            { a: 'Hydrauliekpomp HP-07', t: '2u geleden', s: 'crit' },
            { a: 'Compressor #C-04',     t: '5u geleden', s: 'watch' },
            { a: 'Koelinstallatie KK-05',t: 'Gisteren',   s: 'out' },
          ].map(x => (
            <div key={x.a} style={{ display:'flex', alignItems:'center', gap:10, padding:'8px 0', borderBottom:'0.5px solid var(--border)'}}>
              <IconTile icon="ti-alert-circle" />
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontSize:12, fontWeight:500 }}>{x.a}</div>
                <div style={{ fontSize:11, color:'var(--text-3)' }}>{x.t}</div>
              </div>
              <AssetStateBadge state={x.s} />
            </div>
          ))}
        </Card>
      </div>

      <Card title="Openstaande werkorders" icon="ti-clipboard-list" action="Alles bekijken" flat>
        <table className="tbl">
          <thead><tr><th>WO#</th><th>Omschrijving</th><th>Prioriteit</th><th>Status</th><th>Toegewezen</th><th style={{textAlign:'right'}}>Deadline</th></tr></thead>
          <tbody>
            {MOCK_WO.slice(0, 4).map(w => (
              <tr key={w.id} className="click" onClick={() => openWO(w)}>
                <td className="t-num">{w.id}</td>
                <td><div className="t-desc">{w.desc}</div><div className="t-sub">{w.asset} · {w.loc}</div></td>
                <td><PriorityChip p={w.prio} /></td>
                <td><StatusBadge status={w.status} /></td>
                <td style={{ display:'flex', alignItems:'center', gap:6 }}><Avatar name={w.who} /><span style={{fontSize:12}}>{w.who}</span></td>
                <td style={{ textAlign:'right' }}><span style={{ fontSize:11, color: `var(--${w.dueCls === 'text-2' || w.dueCls === 'text-3' ? w.dueCls : w.dueCls + '-text'})`, fontWeight: w.dueCls === 'red' ? 500 : 400 }}>{w.due}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}

// ── Werkorders screen ─────────────────────────────────────────────
function WerkordersScreen({ workOrders, openWO }) {
  const [filters, setFilters] = useStateS({ open:true, prog:true, wacht:true, done:true, cancel:false });
  const toggle = (k) => setFilters(f => ({ ...f, [k]: !f[k] }));
  const visible = workOrders.filter(w => filters[w.status]);

  return (
    <div className="page">
      <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>
        <FilterChip active={filters.open}   color="open"   dot="var(--blue)"   onClick={()=>toggle('open')}>Open</FilterChip>
        <FilterChip active={filters.prog}   color="prog"   dot="var(--amber)"  onClick={()=>toggle('prog')}>In uitvoering</FilterChip>
        <FilterChip active={filters.wacht}  color="wacht"  dot="var(--purple)" onClick={()=>toggle('wacht')}>Wacht op onderdelen</FilterChip>
        <FilterChip active={filters.done}   color="done"   dot="var(--green)"  onClick={()=>toggle('done')}>Voltooid</FilterChip>
        <FilterChip active={filters.cancel} color="cancel" dot="var(--text-3)" onClick={()=>toggle('cancel')}>Geannuleerd</FilterChip>
        <div className="spacer"></div>
        <span style={{ fontSize:11, color:'var(--text-3)' }}>{visible.length} van {workOrders.length}</span>
      </div>

      <Card flat>
        <table className="tbl">
          <thead><tr><th>WO#</th><th>Omschrijving</th><th>Type</th><th>Prioriteit</th><th>Status</th><th>Toegewezen</th><th style={{textAlign:'right'}}>Deadline</th></tr></thead>
          <tbody>
            {visible.map(w => (
              <tr key={w.id} className="click" onClick={() => openWO(w)}>
                <td className="t-num">{w.id}</td>
                <td><div className="t-desc">{w.desc}</div><div className="t-sub">{w.asset} · {w.loc}</div></td>
                <td style={{ fontSize:11, color:'var(--text-2)', textTransform:'capitalize' }}>{w.kind}</td>
                <td><PriorityChip p={w.prio} /></td>
                <td><StatusBadge status={w.status} /></td>
                <td style={{ display:'flex', alignItems:'center', gap:6 }}><Avatar name={w.who} /><span style={{fontSize:12}}>{w.who}</span></td>
                <td style={{ textAlign:'right', fontSize:11, color: w.dueCls === 'red' ? 'var(--red-text)' : w.dueCls === 'amber' ? 'var(--amber-text)' : 'var(--text-3)', fontWeight: w.dueCls === 'red' ? 500 : 400 }}>{w.due}</td>
              </tr>
            ))}
            {visible.length === 0 && <tr><td colSpan="7" className="empty">Geen werkorders met deze filters</td></tr>}
          </tbody>
        </table>
      </Card>
    </div>
  );
}

// ── Assets screen ─────────────────────────────────────────────────
function AssetsScreen() {
  return (
    <div className="page">
      <div className="grid-4">
        <Kpi icon="ti-building-factory-2" label="Totaal assets"   value="148" sub="6 categorieën" />
        <Kpi icon="ti-circle-check"       label="Operationeel"    value="132" sub="89%" trend="2 vandaag online" trendDir="up"/>
        <Kpi icon="ti-alert-circle"       label="Let op"          value="12"  sub="8% — preventief gepland" />
        <Kpi icon="ti-alert-triangle"     label="Storing"         value={<span style={{color:'var(--red)'}}>4</span>} sub="3% — werkorder actief" trend="1 nieuw vandaag" trendDir="down"/>
      </div>
      <Card flat>
        <table className="tbl">
          <thead><tr><th>ID</th><th>Asset</th><th>Categorie</th><th>Locatie</th><th>Status</th><th style={{textAlign:'right'}}>Open WO</th></tr></thead>
          <tbody>
            {MOCK_ASSETS.map(a => (
              <tr key={a.id} className="click">
                <td className="t-num">{a.id}</td>
                <td style={{ display:'flex', alignItems:'center', gap:10 }}><IconTile icon={a.catIcon} /><div className="t-desc">{a.name}</div></td>
                <td style={{ fontSize:11, color:'var(--text-2)' }}>{a.cat}</td>
                <td style={{ fontSize:11, color:'var(--text-2)' }}>{a.loc}</td>
                <td><AssetStateBadge state={a.state} /></td>
                <td style={{ textAlign:'right', fontSize:11, color:'var(--text-2)' }}>{a.state === 'storing' ? 2 : a.state === 'watch' ? 1 : 0}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}

// ── Onderdelen screen ─────────────────────────────────────────────
function OnderdelenScreen() {
  return (
    <div className="page">
      <div className="grid-4">
        <Kpi icon="ti-box"           label="Totaal onderdelen" value="247" sub="6 categorieën" />
        <Kpi icon="ti-circle-check"  label="Op voorraad"       value="231" sub="94%" />
        <Kpi icon="ti-alert-circle"  label="Lage voorraad"     value="12"  sub="5% — bestel binnenkort" />
        <Kpi icon="ti-x"             label="Niet op voorraad"  value={<span style={{color:'var(--red)'}}>4</span>} sub="1% — directe actie" />
      </div>
      <Card flat>
        <table className="tbl">
          <thead><tr><th>Code</th><th>Naam</th><th>Categorie</th><th style={{textAlign:'right'}}>Voorraad</th><th style={{textAlign:'right'}}>Min</th><th style={{textAlign:'right'}}>Prijs</th><th>Status</th></tr></thead>
          <tbody>
            {MOCK_PARTS.map(p => {
              const tint = p.state === 'empty' ? 'var(--row-tint-crit)' : p.state === 'low' ? 'var(--row-tint-warn)' : 'transparent';
              return (
                <tr key={p.id} className="click" style={{ background: tint }}>
                  <td className="t-num">{p.id}</td>
                  <td><div className="t-desc">{p.name}</div></td>
                  <td style={{ fontSize:11, color:'var(--text-2)' }}>{p.cat}</td>
                  <td style={{ textAlign:'right', fontSize:13, fontWeight:500, color: p.state === 'empty' ? 'var(--red-text)' : p.state === 'low' ? 'var(--amber-text)' : 'var(--text)' }}>{p.stock}</td>
                  <td style={{ textAlign:'right', fontSize:11, color:'var(--text-3)' }}>{p.min}</td>
                  <td style={{ textAlign:'right', fontSize:11, color:'var(--text-2)', fontFamily:'var(--font-mono)' }}>{p.unit}{p.unit2 || ''}</td>
                  <td>
                    {p.state === 'empty' && <span className="badge bg-red">Niet op voorraad</span>}
                    {p.state === 'low'   && <span className="badge bg-amber">Lage voorraad</span>}
                    {p.state === 'ok'    && <span className="badge bg-green">Op voorraad</span>}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </Card>
    </div>
  );
}

// ── Onderhoudsplannen screen ──────────────────────────────────────
function OnderhoudsplannenScreen() {
  return (
    <div className="page">
      <div className="grid-3">
        <Kpi icon="ti-clipboard-text" label="Actieve plannen"  value="24"  sub="op 18 assets" />
        <Kpi icon="ti-calendar-event" label="Deze week"        value="6"   sub="te genereren werkorders" />
        <Kpi icon="ti-alert-circle"   label="Verlopen plannen" value={<span style={{color:'var(--red)'}}>1</span>} sub="5 dagen overschreden" />
      </div>
      <Card flat>
        <table className="tbl">
          <thead><tr><th>HP#</th><th>Plan</th><th>Asset</th><th>Interval</th><th>Volgende</th><th>Status</th></tr></thead>
          <tbody>
            {MOCK_PLANS.map(p => (
              <tr key={p.id} className="click">
                <td className="t-num">{p.id}</td>
                <td><div className="t-desc">{p.name}</div></td>
                <td style={{ fontSize:11, color:'var(--text-2)' }}>{p.asset}</td>
                <td style={{ fontSize:11, color:'var(--text-2)' }}>{p.interval}</td>
                <td style={{ fontSize:12, color: p.state === 'overdue' ? 'var(--red-text)' : 'var(--text)', fontWeight: p.state === 'overdue' ? 500 : 400 }}>{p.next}</td>
                <td>{p.state === 'overdue'
                  ? <span className="badge bg-red">Verlopen</span>
                  : <span className="badge bg-green">Actief</span>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}

Object.assign(window, { DashboardScreen, WerkordersScreen, AssetsScreen, OnderdelenScreen, OnderhoudsplannenScreen });
