/* MAMA Web UI kit — drawers + modal. */

function WorkOrderDrawer({ wo, open, onClose, onComplete }) {
  if (!wo) return null;
  return (
    <>
      <div className={'drawer-overlay' + (open ? ' open' : '')} onClick={onClose}></div>
      <aside className={'drawer' + (open ? ' open' : '')} role="dialog" aria-modal="true">
        <div className="drawer-head">
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ display:'flex', alignItems:'center', gap:8 }}>
              <span className="t-num" style={{fontSize:11}}>{wo.id}</span>
              <PriorityChip p={wo.prio} />
              <StatusBadge status={wo.status} />
            </div>
            <div style={{ fontSize:15, fontWeight:500, marginTop:6 }}>{wo.desc}</div>
            <div style={{ fontSize:11, color:'var(--text-3)', marginTop:2 }}>{wo.asset} · {wo.loc}</div>
          </div>
          <button className="drawer-close" onClick={onClose} aria-label="Sluiten"><i className="ti ti-x"></i></button>
        </div>

        <div className="drawer-body">
          <div className="card" style={{ padding: 0 }}>
            <div style={{ height: 140, background: 'var(--bg)', display:'flex', alignItems:'center', justifyContent:'center', borderTopLeftRadius:10, borderTopRightRadius:10 }}>
              <i className="ti ti-photo" style={{ fontSize: 36, color: 'var(--text-3)' }}></i>
            </div>
            <div style={{ padding: 12 }}>
              <div className="t-desc">{wo.asset}</div>
              <div className="t-sub">Foto wordt opgehaald uit asset-dossier (placeholder).</div>
            </div>
          </div>

          <Card title="Details" icon="ti-info-circle">
            <dl className="kv">
              <dt>Type</dt><dd style={{ textTransform:'capitalize' }}>{wo.kind}</dd>
              <dt>Prioriteit</dt><dd>{PRIO[wo.prio].label}</dd>
              <dt>Toegewezen</dt><dd style={{ display:'flex', alignItems:'center', gap:6 }}><Avatar name={wo.who}/><span>{wo.who}</span></dd>
              <dt>Deadline</dt><dd>{wo.due}</dd>
              <dt>Aangemaakt</dt><dd>Maandag 6 mei 2026 · 09:14</dd>
            </dl>
          </Card>

          <Card title="Benodigde onderdelen" icon="ti-box" action="Beheer">
            <div style={{ display:'flex', flexDirection:'column', gap:8, marginTop:6 }}>
              {[{ n:'Lager 220-15', q:2, code:'BL-220-15', ok:true },
                { n:'Hydrauliekolie ISO 46', q:1, code:'OIL-ISO46', ok:false }].map(p => (
                <div key={p.code} style={{ display:'flex', alignItems:'center', gap:10 }}>
                  <IconTile icon="ti-box" />
                  <div style={{ flex:1 }}>
                    <div className="t-desc">{p.n} <span style={{ fontWeight:400, color:'var(--text-3)', fontSize:11, marginLeft:4 }}>×{p.q}</span></div>
                    <div className="t-sub" style={{ fontFamily:'var(--font-mono)' }}>{p.code}</div>
                  </div>
                  {p.ok
                    ? <span className="badge bg-green">Op voorraad</span>
                    : <span className="badge bg-red">Niet op voorraad</span>}
                </div>
              ))}
            </div>
          </Card>

          <Card title="Activiteit" icon="ti-history">
            <div style={{ display:'flex', flexDirection:'column', gap:8, fontSize:12 }}>
              <div style={{ display:'flex', gap:10 }}>
                <span style={{ fontSize:11, color:'var(--text-3)', minWidth:80 }}>Vandaag 11:02</span>
                <span><strong style={{fontWeight:500}}>J. de Vries</strong> heeft status gewijzigd naar <em style={{fontStyle:'normal', color:'var(--amber-text)'}}>In uitvoering</em>.</span>
              </div>
              <div style={{ display:'flex', gap:10 }}>
                <span style={{ fontSize:11, color:'var(--text-3)', minWidth:80 }}>Maa 09:14</span>
                <span><strong style={{fontWeight:500}}>MAMA AI</strong> heeft deze werkorder gesuggereerd op basis van trillingdata.</span>
              </div>
            </div>
          </Card>
        </div>

        <div className="drawer-foot">
          <Button icon="ti-refresh">Status wijzigen</Button>
          <div className="spacer"></div>
          <Button onClick={onClose}>Annuleren</Button>
          <Button variant="success" icon="ti-check" onClick={()=>onComplete(wo.id)}>Markeer voltooid</Button>
        </div>
      </aside>
    </>
  );
}

function NewWorkOrderModal({ open, onClose, onCreate }) {
  const [form, setForm] = useStateS({
    desc: 'Smering lagerblok lijn 3',
    asset: 'Transportband TB-03',
    prio: 'norm',
    kind: 'preventief',
    who: 'J. de Vries',
    due: 'over 7 dagen',
  });
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));
  const submit = (e) => {
    e.preventDefault();
    onCreate({
      id: 'WO-0' + Math.floor(43 + Math.random() * 60),
      desc: form.desc,
      asset: form.asset,
      loc: 'Hal B',
      prio: form.prio,
      status: 'open',
      who: form.who,
      due: form.due,
      dueCls: 'text-2',
      kind: form.kind,
    });
  };
  return (
    <div className={'modal-overlay' + (open ? ' open' : '')} onClick={onClose}>
      <form className="modal" onClick={e => e.stopPropagation()} onSubmit={submit}>
        <div className="modal-head">
          <i className="ti ti-clipboard-plus" style={{ color:'var(--text-2)' }}></i>
          <span className="modal-title">Nieuwe werkorder</span>
          <div className="spacer"></div>
          <button type="button" className="drawer-close" onClick={onClose} aria-label="Sluiten"><i className="ti ti-x"></i></button>
        </div>
        <div className="modal-body">
          <div className="field full"><label className="field-l">Omschrijving</label><input className="inp" value={form.desc} onChange={e=>set('desc', e.target.value)} /></div>
          <div className="field"><label className="field-l">Asset</label>
            <select className="inp" value={form.asset} onChange={e=>set('asset', e.target.value)}>
              {MOCK_ASSETS.map(a => <option key={a.id}>{a.name}</option>)}
            </select>
          </div>
          <div className="field"><label className="field-l">Type</label>
            <select className="inp" value={form.kind} onChange={e=>set('kind', e.target.value)}>
              <option value="preventief">Preventief</option>
              <option value="correctief">Correctief</option>
              <option value="inspectie">Inspectie</option>
            </select>
          </div>
          <div className="field"><label className="field-l">Prioriteit</label>
            <select className="inp" value={form.prio} onChange={e=>set('prio', e.target.value)}>
              <option value="crit">Kritiek</option>
              <option value="high">Hoog</option>
              <option value="norm">Normaal</option>
              <option value="low">Laag</option>
            </select>
          </div>
          <div className="field"><label className="field-l">Toegewezen</label>
            <select className="inp" value={form.who} onChange={e=>set('who', e.target.value)}>
              <option>J. de Vries</option><option>M. Bakker</option><option>R. Smit</option>
            </select>
          </div>
          <div className="field full"><label className="field-l">Deadline</label><input className="inp" value={form.due} onChange={e=>set('due', e.target.value)} /></div>
          <div className="field full"><label className="field-l">Notities</label><textarea className="inp" placeholder="Optioneel — context, instructies, bijzonderheden…"></textarea></div>
        </div>
        <div className="modal-foot">
          <Button onClick={onClose}>Annuleren</Button>
          <Button variant="primary" icon="ti-plus" type="submit">Aanmaken</Button>
        </div>
      </form>
    </div>
  );
}

Object.assign(window, { WorkOrderDrawer, NewWorkOrderModal });
