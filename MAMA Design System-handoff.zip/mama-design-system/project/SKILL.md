---
name: mama-design
description: Use this skill to generate well-branded interfaces and assets for MAMA — a Dutch-language, Apple-inspired CMMS (Computerized Maintenance Management System) — either for production code or throwaway prototypes, mocks, slides, and demos. Contains essential design guidelines, colors, type, fonts, assets, and a Web UI kit (React/JSX) for prototyping in the MAMA visual language.
user-invocable: true
---

# MAMA — design skill

Read `README.md` next to this file first — it is the source of truth for content fundamentals, visual foundations, iconography, and the index of available files. Then look at:

- `colors_and_type.css` — every color and type token as CSS variables + semantic classes.
- `assets/README.md` — how to use the logo + Tabler icon font.
- `ui_kits/web/` — a working React/JSX UI kit: shell, components, screens, drawers/modal. `ui_kits/web/index.html` is a click-through demo.
- `preview/` — small spec cards (colors, type, components) you can crib from when documenting a new feature.
- `_source/` — read-only snapshot of the imported codebase. Reach for it when you need ground truth.

## How to use this skill

- **Visual artifacts (slides, mocks, throwaway prototypes):** copy assets out of this folder and write static HTML. Always link `colors_and_type.css` first so tokens resolve. Load Inter from Google Fonts and Tabler Icons from `unpkg.com/@tabler/icons-webfont@2.44.0`.
- **Production code:** lift token values, semantic classes, copywriting rules, and the React components in `ui_kits/web/` as a reference. The components are cosmetic — they are not production-ready — but they capture the exact look.
- **Language:** every user-facing string MUST be in Dutch. See § Content Fundamentals in `README.md` for the canonical vocabulary (`Werkorder`, `Asset`, `Onderdeel`, `Storing`, `Onderhoudsplan`, etc.).
- **Tone:** direct, calm, professional. No exclamation marks. No invented emoji — `👋` only in the greeting.
- **Visuals:** white surfaces, 0.5px hairline borders, `Inter` at 10–15px (KPI value 26px), near-black accent. No gradients, no shadows on cards, no display type.

If the user invokes this skill without further guidance, ask what they want to build, ask a couple of clarifying questions (audience, surface — desktop / iPad / mobile, single screen or flow), then act as an expert MAMA designer producing either HTML artifacts or production-shaped code.
