# Assets

This folder holds brand and visual assets for MAMA. There is no proprietary icon or illustration system in the source codebase — all visual material below is documented as **referenced from CDN** or **substituted with a flag**.

## Logo

- **`logo-mark.svg`** — clean 260×260 export of the brand mark only: blue gradient (`#0A84FF → #003E9E`) rounded-square tile with the stylised white `M`. Use this as the icon. Renders crisply at 24/32/40/56/64/96+ px. `border-radius` is baked in.
- **`logo-original.svg`** — full lockup reference (1600×600) supplied by the brand owner. Includes the strapline `"MAMA knows best."` Wordmark text inside this file relies on classes (`.wordmark`, `.subtitle`, `.tagline`) that are not bundled — render the wordmark in HTML/CSS using Inter 600 instead of relying on this SVG's text.
- **Wordmark**: `MAMA` in `Inter 600`, 14px (sidebar) → 30px (display), color `--text`. Tagline `Maintenance Manager` in 10–11px uppercase, letter-spacing 0.6px, color `--text-3`.

See `../preview/logo.html` for the rendered lockup.

## Icons

- **Source:** [Tabler Icons v2.44.0](https://tabler-icons.io) via CDN.
- **CSS:** `https://unpkg.com/@tabler/icons-webfont@2.44.0/tabler-icons.min.css`
- **Usage:** `<i class="ti ti-clipboard-list"></i>` — inherits `currentColor`, rendered at `13–16px`.
- **Canonical icon map** lives in `../README.md` § Iconography.

> ⚠ **Substitution note:** The source codebase does not bundle a local icon font. We pull from the public CDN. If you need offline support, host `tabler-icons.min.css` + the `fonts/tabler-icons.woff2` companion locally.

## Imagery

No imagery exists in the source. The only "image" surfaces in the UI are:

- **Asset photo** in the work-order drawer — meant for real photos of machines. Use `object-fit: cover`, `border-radius: var(--radius-sm)`. When absent, fall back to a Tabler category icon centered on `--bg`.

> ⚠ **Ask the user** if you need actual machine photography. There is no stock library to pull from — leave a placeholder rather than inventing one.

## Fonts

- **Inter** — loaded from Google Fonts: `https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap`. The source codebase uses this same Google Fonts link; no local TTF/WOFF files are vendored.

> ⚠ **Substitution note:** if you need to ship fully offline, download Inter WOFF2 files from [rsms.me/inter](https://rsms.me/inter/) and self-host. Match weights 400 / 500 / 600 exactly — the system never uses 700+.
